<?php

namespace App\Http\Controllers\Commerciale;

use App\Models\User;
use App\Models\Client;
use App\Models\Abonnement;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class CommercialeController extends Controller
{
    public function index()
    {
        $user = User::where('id',Auth::user()->id)->first();
        //  return Auth::user()->id;
          //Récupérer l'abonnement annuel
          $abonnement_a = Abonnement::where('type', 'annuel')->first();
          //Récuperer les clients qui ont un abonnement annuel du commerciale connecté.
          $clients_aa = [];
          if(!empty($abonnement_a)){
              $clients_aa = Client::where('user_id', Auth::user()->id)->where('abonnement_id', $abonnement_a->id)->get();
          }
        return view('commerciale.index',  compact('user', 'clients_aa'));
    }
}
