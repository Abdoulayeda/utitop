<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Facture</title>

</head>
<body>

   
  
    
    <div class="main"> 
       
        <div class="entete">
            
            <div class="entete-left">
                <img src="<?php echo e(public_path('images/logo.png')); ?>" alt="" width="120px">
                <p class="">VDN Cité Villa 04</p>
                <p class="">+221 33 868 54 14</p>
            </div>
            
            
            <div class="entete-right" ALIGN=RIGHT>
                <p><?php echo e($facture->ref_facture); ?></p>
                <p>2023-04-12</p> 
                <p><?php echo e($client->entreprise); ?></p>
                <p><?php echo e($client->prenom); ?> <?php echo e($client->nom); ?> </p>
                <p><?php echo e($client->adresse); ?></p>
                <p><?php echo e($client->telephone); ?></p>
            </div>
        </div>
       
        <div class="date">
            <p>Période du <?php echo e(substr($facture->created_at,0,10)); ?>   <?php echo e($date_end); ?></p>
            
        </div>

        
        <div class="commande">
            
            <p >FACTURE</p> 
            
        </div>
        
         <table class="tableau">
            <thead>
                <th>Désignation</th>
                <th>Référence</th>
                <th>Quantité</th>
                <th>Prix unitaire HT</th>
                <th>Remise</th>
                <th colspan="2">Montant</th>
            </thead>
           
            <tbody>
                    
                <tr>
                    <td>F-<?php echo e($client->formule->type_formule); ?></td>
                    <td>abonnement  <?php echo e($client->abonnement->type); ?></td>
                    <td><?php echo e($client->abonnement->nombres_mois); ?></td> 
                    <td> <?php echo e(number_format($client->formule->tarif, 0, '', ' ')); ?> FCFA</td>   
                    <td></td>
                    
                    <td></td>
                    <td><?php echo e($client->getTotalSansRemise($client->formule->tarif, $client->abonnement->nombres_mois)); ?> FCFA</td>    
                </tr>
                
                <tr>
                    <td><br></td>
                    
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>

                 
                 <tr>
                    <td><br></td>
                    
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>TVA</td>
                    <td></td>
                </tr>
                 
                 
                <tr>
                    
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>Total HT</td>
                    <td><?php echo e($client->getTotalSansRemise($client->formule->tarif, $client->abonnement->nombres_mois )); ?> CFA </td>
                </tr>
                
                <tr>
                    
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>Total <br> TTC</td>

                    <td>
                        <?php echo e($client->getTotalSansRemise($client->formule->tarif, $client->abonnement->nombres_mois )); ?> CFA 
                    </td>
                </tr>
                
                <tr>
                   
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><?php echo e($client->getRemise($client->abonnement->nombres_mois)); ?></td>
                    <td>Net à payer</td>
                    <td>
                        <?php echo e(number_format($client->getTotalAvecRemise($client->formule->tarif,$client->abonnement->nombres_mois), 0, '', ' ')); ?> CFA 
                    </td>
                </tr>
            </tbody>
         </table>
       
        
        <div class="footer-content">
                <p><span class="color-taktyl">Taktyl</span> est une marque commerciale de ALYMIA SAS</p>
               <p>au Capital de 1.000.000 FCFA NINEA 008540892 RCCM SN- DKR- 2021 B 14645</p>
        </div>

        
        <div class="texte">
               <p>Arrêté la présente facture à la somme de  <?php echo e($client->getToLetter(intval($client->getTotalAvecRemise($client->formule->tarif,$client->abonnement->nombres_mois),10))); ?> CFA</p> 
               
        </div>
        
        

    </div>

    <style>
        .main{
            padding: 10px;
        }
        .commande{
            width: 100%;
            justify-content: center;
            align-content: center;
            background-color: rgb(78, 78, 228);
            margin-top: 80px;
        }

      .commande p{
           text-align: center;
           padding: 10px 0  10px 0;
           font-size: 30px;
           color: white;
           font-family: bold;
           margin-bottom: 0; 
     }

     .tableau{
          width: 100%;
     }

     .tableau-thead{
          border-bottom: solid 2px #F38D4E;   
     }

     table {
         border-collapse: collapse;
     }

     table thead th{
         border-left: solid 2px #F38D4E;
         border-right: solid 2px #F38D4E;
         padding: 15px;
     }

     table tbody tr td{
        border: solid 2px #F38D4E;
        text-align: center;
        padding: 10px;
        font-size: 18px;
     }

     .footer-content p{
        text-align: center;
        color: rgb(72, 72, 179);
        font-size: 15px;
     }

    

     .entete-right{
          position: absolute;
          right: 10;
          top: 10px;
     }
     .entete-right p{
          color: rgb(72, 72, 179);   
     }

     .entete-left p{
          color: rgb(72, 72, 179);
     }

     .color-taktyl{
          color:  #F38D4E;
     }

     .texte{
          color: rgb(72, 72, 179);
          font-size: 16px;
     }

     .date{
          margin-left: 60px;
          margin-top: 10px;
          color: rgb(72, 72, 179);
          font-size: 18px;
     }

     

    </style>
</body>
</html><?php /**PATH /home/aliou/Bureau/taktyl/resources/views/commerciale/clients/facture/topdf.blade.php ENDPATH**/ ?>