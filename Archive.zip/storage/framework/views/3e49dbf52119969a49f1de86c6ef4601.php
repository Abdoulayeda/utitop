<?php $__env->startSection('content'); ?>
    <div class="sm:ml-64 bg-orange-500 h-screen">
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mx-6 py-6">
            <div class="shadow-lg hover:shadow-2xl bg-white rounded-lg flex p-4 flex-col justify-center items-center">
                <span class="text-4xl font-bold text-orange-500"><?php echo e(count($user->clients)); ?></span>
                <span class="text-3xl font-bold">Clients</span>
            </div>
            <div class="shadow-lg hover:shadow-2xl bg-white rounded-lg flex p-4 flex-col justify-center items-center">
                <span class="text-4xl font-bold text-orange-500"><?php echo e(count($clients_aa)); ?></span>
                <span class="text-3xl font-bold">Abonnement</span>
                <span class="text-3xl font-bold">annuel</span>
            </div>
            <div class="shadow-lg hover:shadow-2xl bg-white rounded-lg flex p-4 flex-col justify-center items-center">
                <span class="text-4xl font-bold text-orange-500"><?php echo e(count($user->clients) - count($clients_aa)); ?></span>
                <span class="text-3xl font-bold">Abonnement</span>
                <span class="text-3xl font-bold">mensuel</span>
            </div>
            
              
           
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.commerciale', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aliou/Bureau/taktyl/resources/views/commerciale/index.blade.php ENDPATH**/ ?>