@extends('master.admin')

@section('content')
    <div class="sm:ml-[64px]">
        <span>Admin</span>
    </div>
@endsection